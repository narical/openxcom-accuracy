Copy files&folders in OXCE+ directory
Use openxcomRFeat.exe instead of regular openxcom.exe to start game
with new features. You can use openxcom.exe to play with the vanilla
game.

Change "oxceMaxBases" entry in options.cfg file to chose max number
of bases to build. Use RMB click at extremes of minibase-view to see 
"out-of-focus" base. Watch blue arrows to know whether there are 
"out-of-focus" bases at left or right.
